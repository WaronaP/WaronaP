package com.mycompany.poept3;
import java.util.Arrays;

public class POEpt3{

private static String[] removeElement(String[] developer, int deleteIndex) {
    if (developer == null || deleteIndex < 0 || deleteIndex >= developer.length) {
        return developer;
    }
    String[] result = new String[developer.length - 1];
    for (int i = 0, k = 0; i < developer.length; i++) {
        if (i == deleteIndex) {
            continue;
        }
        result[k++] = developer[i];
    }
    return result;
}

private String[] developers;
private String[] taskNames;
private int[] taskIDs;
private int[] taskDurations;
private String[] taskStatuses;


 


    public static void main(String[] args) {

        String[] developer = {"John", "Jane", "Doe"};
        String[] taskNames = {"Task 1", "Task 2", "Task 3"};
        int[] taskID = {1, 2, 3};
        int[] taskDuration = {10, 20, 30};
        String[] taskStatus = {"done", "in progress", "done"};
        

    // Display the Developer, Task Names and Task Duration for all tasks with the status of done.
    for (int i = 0; i < taskStatus.length; i++) {
      if (taskStatus[i].equals("done")) {
        System.out.println("Developer: " + developer[i] + ", Task Name: " + taskNames[i] + ", Task Duration: " + taskDuration[i]);
      }
    }

    // Display the Developer and Duration of the class with the longest duration.
    int maxDurationIndex = 0;
    for (int i = 1; i < taskDuration.length; i++) {
      if (taskDuration[i] > taskDuration[maxDurationIndex]) {
        maxDurationIndex = i;
      }
    }
    System.out.println("Developer: " + developer[maxDurationIndex] + ", Task Duration: " + taskDuration[maxDurationIndex]);

    // Search for a task with a Task Name and display the Task Name, Developer and Task Status.
    String searchTaskName = "Task 2";
    for (int i = 0; i < taskNames.length; i++) {
      if (taskNames[i].equals(searchTaskName)) {
        System.out.println("Task Name: " + taskNames[i] + ", Developer: " + developer[i] + ", Task Status: " + taskStatus[i]);
      }
    }

    // Search for all tasks assigned to a developer and display the Task Name and Task Status.
    String searchDeveloperName = "";
    for (int i = 0; i < developer.length; i++) {
      if (developer[i].equals(searchDeveloperName)) {
        System.out.println("Task Name: " + taskNames[i] + ", Task Status: " + taskStatus[i]);
      }
    }

    // Delete a task using the Task Name.
    String deleteTaskName = "Task 3";
    int deleteIndex = -1;
    for (int i = 0; i < taskNames.length; i++) {
      if (taskNames[i].equals(deleteTaskName)) {
        deleteIndex = i;
        break;
      }
    }

if (deleteIndex != -1) {
      developer = removeElement(developer, deleteIndex);
      taskNames = removeElement(taskNames, deleteIndex);
      taskStatus = removeElement(taskStatus, deleteIndex);
      System.out.println(deleteTaskName + " has been deleted.");
    } else {
      System.out.println(deleteTaskName + " not found.");
    }

    // Display a report that lists the full details of all captured tasks
    System.out.println(Arrays.toString(developer));
    System.out.println(Arrays.toString(taskNames));
    System.out.println(Arrays.toString(taskID));
    System.out.println(Arrays.toString(taskDuration));
    System.out.println(Arrays.toString(taskStatus));
  }


public class Main {
  public static String[] removeElement(String[] arr, int index) {
    if (arr == null || index < 0 || index >= arr.length) {
      return arr;
    }
    
    String[] result = new String[arr.length - 1];
    
    for (int i = 0, k = 0; i < arr.length; i++) {
      if (i == index) {
        continue;
      }
      
      result[k++] = arr[i];
    }
    
    return result;
  }

  public static int[] removeElement(int[] arr, int index) {
    if (arr == null || index < 0 || index >= arr.length) {
      return arr;
    }
    
    int[] result = new int[arr.length - 1];
    
    for (int i = 0, k = 0; i < arr.length; i++) {
      if (i == index) {
        continue;
      }
      
      result[k++] = arr[i];
    }
    
    return result;
  }



    public void displayDoneTasks() {
        System.out.println("Developer"
                         + "\tTask Name"
                         + "\tTask Duration");
        for (int i = 0; i < taskStatuses.length; i++) {
            if (taskStatuses[i].equals("done")) {
                System.out.println(developers[i] 
                           +"\t" + taskNames[i] 
                          + "\t" + taskDurations[i]);
            }
        }
    }

    public void displayLongestTask() {
        int maxDurationIndex = 0;
        for (int i = 1; i < taskDurations.length; i++) {
            if (taskDurations[i] > taskDurations[maxDurationIndex]) {
                maxDurationIndex = i;
            }
        }
        System.out.println("Developer: " + developers[maxDurationIndex]);
        System.out.println("Task Duration: " + taskDurations[maxDurationIndex]);
    }

    public void searchTaskByName(String name) {
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(name)) {
                System.out.println("Task Name: " + taskNames[i]);
                System.out.println("Developer: " + developers[i]);
                System.out.println("Task Status: " + taskStatuses[i]);
                return;
            }
        }
        System.out.println("Task not found.");
    }

    public void searchTasksByDeveloper(String developer) {
        boolean found = false;
        for (int i = 0; i < developers.length; i++) {
            if (developers[i].equals(developer)) {
                found = true;
                System.out.println("Task Name: " + taskNames[i]);
                System.out.println("Task Status: " + taskStatuses[i]);
            }
        }
        if (!found) {
            System.out.println("No tasks found for developer.");
        }
    }

    public void deleteTaskByName(String name) {
        int indexToDelete = -1;
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(name)) {
                indexToDelete = i;
                break;
            }
        }
        if (indexToDelete == -1) {
            System.out.println("Task not found.");
            return;
        }
        
        String[] newDevelopers = new String[developers.length - 1];
        String[] newTaskNames = new String[taskNames.length - 1];
        int[] newTaskIDs = new int[taskIDs.length - 1];
        int[] newTaskDurations = new int[taskDurations.length - 1];
        String[] newTaskStatuses = new String[taskStatuses.length - 1];

        for (int i = 0, j = 0; i < developers.length; i++) {
            if (i == indexToDelete) continue;

            newDevelopers[j] = developers[i];
            newTaskNames[j] = taskNames[i];
            newTaskIDs[j] = taskIDs[i];
            newTaskDurations[j] = taskDurations[i];
            newTaskStatuses[j] = taskStatuses[i];
            j++;
        }

        developers = newDevelopers;
        taskNames = newTaskNames;
        taskIDs = newTaskIDs;
        taskDurations = newTaskDurations;
        taskStatuses = newTaskStatuses;

        System.out.println("Task deleted.");
    }

    public void displayReport() {
      System.out.println("Developer\tTask Name\tTask ID\tTask Duration\tTask Status");
      for (int i=0;i<developers.length;i++){
          System.out.println(developers[i]+"\t"+taskNames[i]+"\t"+taskIDs[i]+"\t"+taskDurations[i]+"\t"+taskStatuses[i]);
      }
    }
}
}

